ScrollReveal().reveal('#home', {delay:800, reset:true});
ScrollReveal().reveal('#tecnologias', {delay:800, reset:true});
ScrollReveal().reveal('#proyectos', {delay:800, reset:true});
ScrollReveal().reveal('#contacto', {delay:800, reset:true});