
<?php $__env->startSection('content'); ?>
    <div class="container margen">
        <div class="row">
            <div class="col text-center">
                <a href="<?php echo e(url('/proyectos')); ?>" class="btn btn-danger px-5 py-3">Proyectos</a>
            </div>
        </div>
        <br>
        <hr>
        <br>
        <div class="row">
            <div class="col">
                <h3 class="text-center text-primary">
                    Contactos
                </h3>
            </div>
        </div>
        <?php echo $__env->make('dashboard.contactos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', [$titulo = 'Andres Rincon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PORTAFOLIO\AndresRincon\resources\views/dashboard.blade.php ENDPATH**/ ?>