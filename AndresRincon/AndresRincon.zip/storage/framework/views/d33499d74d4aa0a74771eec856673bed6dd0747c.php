<div class="row">
<?php $__currentLoopData = $contactos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><strong>Nombre: </strong><?php echo e($contacto->nombre); ?></h5>
                <h5 class="card-title"><strong>Teléfono: </strong><?php echo e($contacto->telefono); ?></h5>
                <h5 class="card-title"><strong>Correo: </strong><?php echo e($contacto->correo); ?></h5>
                <h5 class="card-title"><strong>Empresa: </strong><?php echo e($contacto->empresa); ?></h5>
                <h5 class="card-title"><strong>Solicitud: </strong><?php echo e($contacto->servicio); ?></h5>
                <p class="card-text"><?php echo e($contacto->mensaje); ?></p>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\xampp\htdocs\PORTAFOLIO\AndresRincon\resources\views/dashboard/contactos.blade.php ENDPATH**/ ?>