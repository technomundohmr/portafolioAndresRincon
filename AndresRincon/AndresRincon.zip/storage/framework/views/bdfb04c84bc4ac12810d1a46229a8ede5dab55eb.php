<div class="perfil-light" id="home">
    <div class="container mt-5 py-5">
        <div class="row">
            <div class="col-md-6">
                <div >
                    <img class="foto" src="img/foto.jpeg" alt="" width="100%">
                </div>
            </div>
            <div class="col-md-6">
                <div class="perfil my-5 p-5 text-justify">
                    <h4 class="my-5">Perfil</h4>
                    <p>Programador web fullstack bilingüe, con conocimiento en PHP y uso de framework Laravel, ademas de las tecnologás esenciales de la web como HTML 5, CSS, JS.</p>
                    <p>Programador web con conocimiento en implementacion y uso de bases de datos relacionales en tecnología MySQL. También con manejo de servidor XAMPP, en la fase de desarrollo y CPanel, en la fase de producción</p>
                    <p>Desarrollador con conocimiento y experiencia minima en wordpress</p>
                    <p>Persona con amor al aprendizaje y los retos.</p>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\PORTAFOLIO\AndresRincon\resources\views/home/perfil.blade.php ENDPATH**/ ?>