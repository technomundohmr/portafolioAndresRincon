<div class="proyectos my-5" id="proyectos">
    <div class="container">
        <div class="row">
            <div class="col">
                <h3 class="text-center my-3">Proyects</h3>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="table-responsive">
                    <table class="table table-bordered text-center">
                        <thead class="table-secondary">
                            <tr>
                                <th>Proyect</th>
                                <th>Description</th>
                                <th>Links</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($proyecto->proyecto); ?></td>
                                <td><?php echo e($proyecto->descripcion); ?></td>
                                <td>
                                    <a href="<?php echo e($proyecto->enlace); ?>" target="_blank" class="btn btn-success"><i class="fas fa-code"></i> Visitar</a>
                                    <?php if($proyecto->git != ''): ?>
                                        <a href="<?php echo e($proyecto->git); ?>" target="_blank" class="btn btn-primary"><i class="fab fa-github"></i> Github</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\PORTAFOLIO\AndresRincon\resources\views/homeEn/proyects.blade.php ENDPATH**/ ?>