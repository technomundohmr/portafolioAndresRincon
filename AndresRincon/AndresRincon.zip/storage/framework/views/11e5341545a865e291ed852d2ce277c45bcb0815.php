
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard.formProyects', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <hr>
    <?php echo $__env->make('home.proyectos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainEn', [$titulo = 'Andres Rincon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PORTAFOLIO\AndresRincon\resources\views/proyectos.blade.php ENDPATH**/ ?>