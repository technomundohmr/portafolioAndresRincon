<header>
    <div class="headerImg">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                </div>
                <div class="col-md-6">
                    <div class="mensaje light-menu text-center" id="homeHeader">
                        <p class="fst-italic ">
                            "Nunca pares de aprender. El paso más difícil es el primero"
                        </p>
                        <p>
                            <strong> Andrés Rincón </strong>- Fullstack web developer
                        </p>
                        <a href="https://github.com/technomundohmr" class="btn btn-primary mx-auto" target="_blank"><i class="fab fa-github"></i> GitHub</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header><?php /**PATH C:\xampp\htdocs\PORTAFOLIO\AndresRincon\resources\views/home/headerImg.blade.php ENDPATH**/ ?>