<a href="<?php echo e(url('/')); ?>" class="text-decoration-none">
    <div class="btnIdioma p-2 text-center">
        <h2><i class="fas fa-globe-americas"></i></h2>
        <p>ES</p>
    </div>
</a><?php /**PATH C:\xampp\htdocs\PORTAFOLIO\AndresRincon\resources\views/layout/btnIdiomaEn.blade.php ENDPATH**/ ?>