<header>
    <div class="headerImg">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                </div>
                <div class="col-md-6">
                    <div class="mensaje light-menu text-center" id="homeHeader">
                        <p class="fst-italic ">
                            "Never stop to learn. The hardest step is the first one"
                        </p>
                        <p>
                            <strong> Andrés Rincón </strong>- Fullstack web developer
                        </p>
                        <a href="https://github.com/technomundohmr" class="btn btn-primary mx-auto" target="_blank"><i class="fab fa-github"></i> GitHub</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>