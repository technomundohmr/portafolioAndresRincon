<div class="perfil-light" id="home">
    <div class="container mt-5 py-5">
        <div class="row">
            <div class="col-md-6">
                <div >
                    <img class="foto" src="img/foto.jpeg" alt="" width="100%">
                </div>
            </div>
            <div class="col-md-6">
                <div class="perfil my-5 p-5 text-justify">
                    <h4 class="my-5">Profile</h4>
                    <p>Bilingual fullstack web developer, whit knowleage in PHP and use of framework Laravel, also essential web tecnologies as HTML 5, CSS, JS.</p>
                    <p>Fullstack web developer whit knowleage in implementation and use of relational databases in tecnología MySQL.  As well whit server knowleadge in XAMPP, on development and CPanel, on production.</p>
                    <p>Developer whit knowleade and experience on wordpress</p>
                    <p>Person whit love in learning and challenges</p>
                </div>
            </div>
        </div>
    </div>
</div>