<a href="{{url('/')}}" class="text-decoration-none">
    <div class="btnIdioma p-2 text-center">
        <h2><i class="fas fa-globe-americas"></i></h2>
        <p>ES</p>
    </div>
</a>