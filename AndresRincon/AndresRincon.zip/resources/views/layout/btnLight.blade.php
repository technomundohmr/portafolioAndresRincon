<div class="btnLight" id="btnLight">
    <h2><i class="fas fa-lightbulb"></i></h2>
</div>
<div class="btnDark d-none" id="btnDark">
    <h2><i class="fas fa-lightbulb"></i></h2>
</div>